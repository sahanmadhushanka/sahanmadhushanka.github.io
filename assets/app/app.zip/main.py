import flet as ft
from views.home import home_view
from views.about import about_view
from views.researches import researches_view
from views.qualification import qualification_view
from views.services import services_view
from views.contact import contact_view
from components.navbar import navbar

def main(page: ft.Page):
    page.title = "Developios | Digital Agency Portfolio"
    page.bgcolor = "#050e17"
    page.padding = 0
    page.margin = 0
    page.spacing = 0

    page.theme = ft.Theme(
        navigation_drawer_theme=ft.NavigationDrawerTheme(
            indicator_color=ft.Colors.TRANSPARENT,
            indicator_shape=ft.RoundedRectangleBorder(radius=0),
        )
    )

    # 💡 මෙනුව ඕපන්/ක්ලෝස් තත්ත්වය නිරීක්ෂණය කරන Variable එක
    drawer_is_open = False
    selected_menu = "HOME"

    # 🔄 RESPONSIVE LOGIC
    def on_page_resize(e):
        page.update()

    # 💡 1. මෙනුව වහන (Close කරන) ශ්‍රිතය
    def close_drawer(e):
        nonlocal drawer_is_open
        drawer_is_open = False
        page.drawer.open = False
        page.update()

    # 💡 2. මෙනුව ඕපන් කරන ශ්‍රිතය
    def open_drawer(e):
        nonlocal drawer_is_open
        drawer_is_open = True
        page.drawer.open = True
        page.update()

    def drawer_dismissed(e):
        nonlocal drawer_is_open
        drawer_is_open = False

    def menu_click(menu_name):
        nonlocal selected_menu, drawer_is_open
        selected_menu = menu_name
        drawer_is_open = False
        page.drawer.open = False
        if menu_name == "HOME":
            page.go("/")

        elif menu_name == "ABOUT ME":
            page.go("/about")

        elif menu_name == "RESEARCHES":
            page.go("/researches")

        elif menu_name == "QUALIFICATION":
            page.go("/qualification")

        elif menu_name == "SERVICES":
            page.go("/services")

        elif menu_name == "CONTACT":
            page.go("/contact")

        build_drawer()
        page.update()

    # 💡 එක මෙනු අයිතමයක් (Row එකක්) සාදන ෆන්ෂන් එක
    def make_menu_item(icon, text_value):
        is_selected = (text_value == selected_menu)
        item_color = "#00ffea" if is_selected else "#FFFFFF"
        item_weight = "bold" if is_selected else "normal"

        return ft.Container(
            padding=ft.padding.symmetric(horizontal=20, vertical=12),
            on_click=lambda e: menu_click(text_value),
            content=ft.Row(
                controls=[
                    ft.Icon(name=icon, color=item_color, size=16),
                    ft.Text(text_value, color=item_color, size=14, weight=item_weight)
                ],
                spacing=15
            )
        )

    # 💡 මෙනුව ඇතුලේ තියෙන controls ටික අලුතෙන් පාට කරලා හදන ෆන්ෂන් එක
    def build_drawer():
        page.drawer.controls = [
            ft.Container(height=10),
            ft.Row(
                controls=[
                    ft.IconButton(icon=ft.Icons.CLOSE, icon_color="white", on_click=close_drawer)
                ],
                alignment=ft.MainAxisAlignment.END
            ),
            ft.Container(
                content=ft.Text("MENU", size=22, weight="bold", color="white"),
                padding=20
            ),
            ft.Divider(color="#00ffea"),

            make_menu_item(ft.Icons.HOME, "HOME"),
            make_menu_item(ft.Icons.INFO, "ABOUT ME"),
            make_menu_item(ft.Icons.SEARCH, "RESEARCHES"),
            make_menu_item(ft.Icons.BOOKMARK, "QUALIFICATION"),
            make_menu_item(ft.Icons.SETTINGS, "SERVICES"),
            make_menu_item(ft.Icons.CALL, "CONTACT"),
        ]

    # 📱 INITIAL NAVIGATION DRAWER SETTING
    page.drawer = ft.NavigationDrawer(
        bgcolor=ft.Colors.with_opacity(0.4, "#686868"),
        shadow_color=ft.Colors.TRANSPARENT,
        elevation=0,
        on_dismiss=drawer_dismissed,
        controls=[]
    )

    build_drawer()

    page.on_resize = on_page_resize

    def route_change(e):
        page.views.clear()

        if page.route == "/":
            page.views.append(
                home_view(page)
            )

        elif page.route == "/about":
            page.views.append(
                about_view(page)
            )
        elif page.route == "/contact":
            page.views.append(
                contact_view(page)
            )
        elif page.route == "/qualification":
            page.views.append(
                qualification_view(page)
            )
        elif page.route == "/researches":
            page.views.append(
                researches_view(page)
            )
        elif page.route == "/services":
            page.views.append(
                services_view(page)
            )

        page.update()

    page.on_route_change = route_change
    page.go("/")
    page.update()

# ඇප් එක රන් කරන කමාන්ඩ් එක
ft.app(target=main, view=ft.AppView.WEB_BROWSER, assets_dir="assets")