import flet as ft
from components.navbar import navbar

def researches_view(page):
    return ft.View(
        route="/researches",
        padding=0,
        spacing=0,
        vertical_alignment=ft.MainAxisAlignment.START,
        drawer=page.drawer,
        controls=[
            ft.Stack(
                expand=True,
                controls=[
                    # ලේයර් 1: 🖼️ පසුබිම් පින්තූරය
                    ft.Container(
                        top=0, left=0, right=0, bottom=0,
                        content=ft.Image(
                            src="/my_bg.jpeg",
                            fit=ft.ImageFit.COVER


                        )
                    ),

                    # ලේයර් 2: 🖤 කළු පාට Shadow Overlay එක
                    ft.Container(
                        top=0, left=0, right=0, bottom=0,
                        gradient=ft.LinearGradient(
                            begin=ft.alignment.top_center,
                            end=ft.alignment.bottom_center,
                            colors=[
                                ft.Colors.with_opacity(0.4, "black"),
                                ft.Colors.with_opacity(0.8, "black")
                            ]
                        )
                    ),

                    # ලේයර් 3: 📱 මැදින් සෙන්ටර් වෙලා පෙනෙන ටෙක්ස්ට් එක
                    ft.Container(
                        top=0, left=0, right=0, bottom=0,
                        alignment=ft.alignment.center,
                        content=ft.Column(
                            controls=[

                                ft.Text(
                                    "Researches",
                                    size=55,
                                    color="white",
                                    weight="bold"
                                ),

                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=10
                        )
                    ),

                    # 🌟 ලේයර් 4: 👑 හැමදේටම උඩින් පෙනෙන සහ CLICK 100% වැඩ කරන මෙනු බාර් එක
                    ft.Container(
                        top=25,
                        left=20,
                        right=20,
                        content=navbar(page)
                    )
                ]
            )
        ]
    )
