import flet as ft

def navbar(page):
    def create_nav_item(text_value, route):

        def on_hover(e):
            if e.data == "true":
                nav_container.bgcolor = "#00152c"
                nav_container.border = ft.border.only(
                    bottom=ft.BorderSide(3, "#00ffea")
                )
                text_control.color = "#00ffea"
                text_control.weight = "bold"

            else:
                nav_container.bgcolor = ft.Colors.TRANSPARENT
                nav_container.border = None
                text_control.color = "#FFFFFF"
                text_control.weight = ft.FontWeight.W_500

            nav_container.update()

        text_control = ft.Text(
            text_value,
            color="#FFFFFF",
            size=13,
            weight=ft.FontWeight.W_500
        )

        nav_container = ft.Container(
            content=text_control,
            padding=ft.padding.only(
                left=20,
                right=20,
                top=10,
                bottom=8
            ),
            bgcolor=ft.Colors.TRANSPARENT,
            border_radius=20,
            animate=ft.animation.Animation(
                150,
                ft.AnimationCurve.EASE_IN_OUT
            ),
            on_hover=on_hover,
            on_click=lambda e: page.go(route)
        )

        return nav_container

        # text_control = ft.Text(text_value, color="#FFFFFF", size=13, weight=ft.FontWeight.W_500)
        #
        # nav_container = ft.Container(
        #     content=text_control,
        #     padding=ft.padding.only(left=20, right=20, top=10, bottom=8),
        #     bgcolor=ft.Colors.TRANSPARENT,
        #     border_radius=ft.border_radius.all(20),
        #     animate=ft.animation.Animation(150, ft.AnimationCurve.EASE_IN_OUT),
        #     on_hover=on_hover
        # )
        # return nav_container

    desktop_menu = ft.Row(
        controls=[
            create_nav_item("HOME", "/"),
            create_nav_item("ABOUT ME", "/about"),
            create_nav_item("RESEARCHES", "/researches"),
            create_nav_item("QUALIFICATIONS", "/qualification"),
            create_nav_item("SERVICES", "/services"),
            create_nav_item("CONTACT", "/contact"),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
    )

    # 🍔 2. MOBILE MENU ICON
    def open_mobile_menu(e):
        page.drawer.open = True
        page.update()

    mobile_menu_icon = ft.IconButton(
        icon=ft.Icons.MENU,
        icon_color="white",
        icon_size=28,
        on_click=open_mobile_menu
    )

    navbar = ft.ResponsiveRow(
        controls=[
            ft.Container(content=desktop_menu, col={"xs": 0, "md": 12}),
            ft.Container(content=mobile_menu_icon, col={"xs": 12, "md": 0}, alignment=ft.alignment.center_left),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
    )
    navbar = ft.ResponsiveRow(
        controls=[
            ft.Container(
                content=desktop_menu,
                col={"xs": 0, "md": 12},
            ),
            ft.Container(
                content=mobile_menu_icon,
                col={"xs": 12, "md": 0},
                alignment=ft.alignment.center_left,
                padding=ft.padding.only(left=10),
            ),
        ]
    )

    return navbar

